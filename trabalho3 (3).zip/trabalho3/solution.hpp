#pragma once

#include <iostream>
#include <algorithm>

#include "instance.hpp"
#include "pair.hpp"
#include "grupo.hpp"
#include "lista_elementos.hpp"
#include "funcoes.hpp"

using namespace std;
class Solution
{
public:
    Instance instance;
    double resultado;
    vector<Grupo> solucao;

    vector<vector<Grupo>> vizinhos;

    Solution()
    {
        cout << "SOLUTION INICIADA";
    }
    Solution(Instance instance)
    {
        this->instance = instance;
    }

    // distribui os elementos aleatoriamente para ter um resultado ruim para comparar com a heurística
    vector<Grupo> calcular_resultado_ruim()
    {

        Funcoes funcoes;

        vector<int> elementos;
        elementos = funcoes.get_elementos(instance.arr_Pair);

        vector<Grupo> grupos;
        grupos = funcoes.get_grupos(instance);

        while (elementos.size() > 0)
        {
            for (int i = 0; i < instance.quant_Grup; i++)
            {
                if (grupos[i].elementos.size() < grupos[i].tam_minimo)
                {
                    grupos[i].elementos.push_back(elementos[elementos.size() - 1]);
                    elementos.pop_back();
                }
            }
            for (int i = 0; i < instance.quant_Grup; i++)
            {
                if (elementos.size() == 0)
                {
                    break;
                }
                if (grupos[i].elementos.size() < grupos[i].tam_maximo)
                {
                    grupos[i].elementos.push_back(elementos[elementos.size() - 1]);
                    elementos.pop_back();
                }
            }
        }

        return grupos;
    }

    vector<Grupo> calcular_resultado()
    {

        Funcoes funcoes;

        int quantidade_elementos = instance.quant_Elem;
        vector<int> elementos = funcoes.get_elementos(instance.arr_Pair);
        vector<Grupo> grupos = funcoes.get_grupos(instance);

        int space = 0;

        // nessa etapa garantimos que todos os tamanhos mínimos foram preenchidos
        bool while1 = true;
        while (while1)
        {
            while1 = false;
            for (int i = 0; i < grupos.size(); i++)
            {
                if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                {
                    funcoes.alocar_elemento(grupos[i], elementos, elementos.back());
                    while1 = true;
                }
            }
        }

        // adiciona os elementos restantes nas melhores posições
        while (elementos.size() > 0)
        {
            int position = funcoes.get_best_group(grupos, elementos.back(), instance.arr_Pair);
            funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());
        }

        return grupos;
    }

    vector<Grupo> calcular_resultado2()
    {

        Funcoes funcoes;

        int quantidade_elementos = instance.quant_Elem;
        vector<int> elementos = funcoes.get_elementos(instance.arr_Pair);
        vector<Grupo> grupos = funcoes.get_grupos(instance);

        int space = 0;
        for (int i = 0; i < grupos.size(); i++)
        {
            space += grupos[i].tam_minimo;
        }

        bool while1 = true;
        bool primeira_vez_no_while = true;

        while (while1)
        {
            while1 = false;

            if (space == elementos.size() or primeira_vez_no_while)
            {

                primeira_vez_no_while = false;

                for (int i = 0; i < grupos.size(); i++)
                {
                    if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                    {

                        funcoes.alocar_elemento(grupos[i], elementos, elementos.back());
                        space -= 1;
                        while1 = true;
                    }
                }
            }
            else
            {

                for (int i = 0; i < grupos.size(); i++)
                {
                    if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                    {
                        while1 = true;
                    }
                }

                int position = funcoes.get_best_group(grupos, elementos.back(), instance.arr_Pair);
                funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());
                if (grupos[grupos[position].i].get_quantidade_elementos() <= grupos[grupos[position].i].tam_minimo)
                {
                    space -= 1;
                }
            }
        }

        while (elementos.size() > 0)
        {
            int position = funcoes.get_best_group(grupos, elementos.back(), instance.arr_Pair);
            funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());
        }

        return grupos;
    }

    vector<Grupo> calcular_resultado3()
    {

        Funcoes funcoes;

        int quantidade_elementos = instance.quant_Elem;
        vector<int> elementos = funcoes.get_elementos(instance.arr_Pair);
        vector<Grupo> grupos = funcoes.get_grupos(instance);
        int space = 0;

        for (int i = 0; i < grupos.size(); i++)
        {
            space += grupos[i].tam_minimo;
        }

        // nessa etapa garantimos que todos os tamanhos mínimos foram preenchidos
        bool while1 = true;

        while (while1)
        {
            while1 = false;

            // se espaço é igual a quantidade restante de elementos, então
            // necessariamente precisamos alocar elementos em grupos
            // que ainda não tiveram o tamanho mínimo preenchido
            if (space == elementos.size())
            {

                // cout<<"caso 1"<<endl;

                for (int i = 0; i < grupos.size(); i++)
                {

                    // se ainda tem grupos sem tamanho mínimo preenchido continuamos no while
                    // e adicionamos um elemento no grupo que não tem o
                    // tamanho mínimo preenchido
                    if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                    {

                        funcoes.alocar_elemento(grupos[i], elementos, elementos.back());
                        space -= 1;
                        while1 = true;
                    }
                }
            }
            else
            {
                for (int i = 0; i < grupos.size(); i++)
                {
                    // se ainda tem grupos sem tamanho mínimo preenchido continuamos no while
                    if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                    {
                        while1 = true;
                    }
                }

                int position = funcoes.get_best_group(grupos, elementos.back(), instance.arr_Pair);
                funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());
                if (grupos[grupos[position].i].get_quantidade_elementos() <= grupos[grupos[position].i].tam_minimo)
                {
                    space -= 1;
                }
            }
        }

        // adiciona os elementos restantes nas melhores posições
        while (elementos.size() > 0)
        {
            int position = funcoes.get_best_group(grupos, elementos.back(), instance.arr_Pair);
            funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());
        }

        return grupos;
    }

    vector<Grupo> calcular_resultado4()
    {

        Funcoes funcoes;

        int quantidade_elementos = instance.quant_Elem;
        vector<int> elementos = funcoes.get_elementos(instance.arr_Pair);
        vector<Grupo> grupos = funcoes.get_grupos(instance);

        int space = 0;
        for (int i = 0; i < grupos.size(); i++)
        {
            space += grupos[i].tam_minimo;
        }

        // nessa etapa garantimos que todos os tamanhos mínimos foram preenchidos
        bool while1 = true;
        bool primeira_vez_no_while = true;

        while (while1)
        {
            while1 = false;

            // se espaço é igual a quantidade restante de elementos, então
            // necessariamente precisamos alocar elementos em grupos
            // que ainda não tiveram o tamanho mínimo preenchido
            if (space == elementos.size() or primeira_vez_no_while)
            {

                if (primeira_vez_no_while)
                {
                    for (int i = 0; i < grupos.size(); i++)
                    {

                        // se ainda tem grupos sem tamanho mínimo preenchido continuamos no while
                        if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                        {

                            funcoes.alocar_elemento(grupos[i], elementos, elementos.back());
                            space -= 1;
                            while1 = true;
                        }
                    }
                }

                primeira_vez_no_while = false;

                for (int i = 0; i < grupos.size(); i++)
                {

                    // se ainda tem grupos sem tamanho mínimo preenchido continuamos no while
                    if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                    {

                        int position = funcoes.get_best_group2(grupos, elementos.back(), instance.arr_Pair);
                        funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());

                        space -= 1;
                        while1 = true;
                    }
                }
            }
            else
            {

                for (int i = 0; i < grupos.size(); i++)
                {
                    // se ainda tem grupos sem tamanho mínimo preenchido continuamos no while
                    if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                    {
                        while1 = true;
                    }
                }

                int position = funcoes.get_best_group(grupos, elementos.back(), instance.arr_Pair);
                funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());
                if (grupos[grupos[position].i].get_quantidade_elementos() <= grupos[grupos[position].i].tam_minimo)
                {
                    space -= 1;
                }
            }
        }

        // adiciona os elementos restantes nas melhores posições
        while (elementos.size() > 0)
        {
            int position = funcoes.get_best_group(grupos, elementos.back(), instance.arr_Pair);
            funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());
        }

        return grupos;
    }


    //ESSE É A FUNÇÃO USADA NO TRABALHO, COM A  HEURÍSTICA
    vector<Grupo> calcular_resultado5()
    {

        Funcoes funcoes;

        int quantidade_elementos = instance.quant_Elem;
        vector<int> elementos = funcoes.get_elementos(instance.arr_Pair);
        vector<Grupo> grupos = funcoes.get_grupos(instance);
        int space = 0;

        for (int i = 0; i < grupos.size(); i++)
        {
            space += grupos[i].tam_minimo;
        }

        // nessa etapa garantimos que todos os tamanhos mínimos foram preenchidos
        bool while1 = true;
        bool primeira_vez_no_while = true;

        while (while1)
        {
            while1 = false;

            if (space == elementos.size() or primeira_vez_no_while)
            {

                if (primeira_vez_no_while)
                {
                    for (int i = 0; i < grupos.size(); i++)
                    {

                        // se ainda tem grupos sem tamanho mínimo preenchido continuamos no while
                        if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                        {

                            funcoes.alocar_elemento(grupos[i], elementos, elementos.back());
                            space -= 1;
                            while1 = true;
                        }
                    }
                }

                primeira_vez_no_while = false;

                for (int i = 0; i < grupos.size(); i++)
                {

                    // se ainda tem grupos sem tamanho mínimo preenchido continuamos no while
                    if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                    {
                        int position = funcoes.get_best_group3(grupos, elementos.back(), instance.arr_Pair);
                        funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());

                        space -= 1;
                        while1 = true;
                    }
                }
            }

            else
            {

                for (int i = 0; i < grupos.size(); i++)
                {
                    // se ainda tem grupos sem tamanho mínimo preenchido continuamos no while
                    if (grupos[i].get_quantidade_elementos() < grupos[i].tam_minimo)
                    {
                        while1 = true;
                    }
                }

                int position = funcoes.get_best_group3(grupos, elementos.back(), instance.arr_Pair);
                funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());
                if (grupos[grupos[position].i].get_quantidade_elementos() <= grupos[grupos[position].i].tam_minimo)
                {
                    space -= 1;
                }
            }
        }

        // adiciona os elementos restantes nas melhores posições
        while (elementos.size() > 0)
        {
            int position = funcoes.get_best_group3(grupos, elementos.back(), instance.arr_Pair);
            funcoes.alocar_elemento(grupos[grupos[position].i], elementos, elementos.back());
        }

        this->solucao= grupos;

        return grupos;
    }

  
    double limite_superior(){
        int tamanho = instance.arr_Pair.size();
        double total = 0.0;
        vector<Pair> distances = instance.arr_Pair;
   
        for(int i=0;i<tamanho;i++){
                      
            total+= distances[i].get_distance_Element();
        }
        return total;
    }

    double limite_superior2(){

        Funcoes funcoes;    

        vector<Grupo> grupos = funcoes.get_grupos(instance);

        int quantidade_elementos = instance.quant_Elem;

        vector<Grupo> grupos_ordenados_por_tamanho_minimo = grupos;
        funcoes.ordenar_tam_minimo(grupos_ordenados_por_tamanho_minimo);

        vector<Grupo> grupos_ordenados_por_tamanho_maximo = grupos;
        funcoes.ordenar_tam_maximo(grupos_ordenados_por_tamanho_maximo);

        int distances_total;
        distances_total = instance.arr_Pair[instance.arr_Pair.size()-1].second_Element;

        for(int i = 0; i< grupos.size();i++){
            grupos_ordenados_por_tamanho_minimo[i].tam_maximo = grupos_ordenados_por_tamanho_maximo[i].tam_maximo;
        }

        for(int i = 0;i<grupos.size();i++){
            grupos[i].i = grupos[i].tam_minimo;
            quantidade_elementos-=grupos[i].i;
        }

        

        for(int i = grupos_ordenados_por_tamanho_minimo.size() -1 ; i>=0; i--){
        
            while(grupos_ordenados_por_tamanho_minimo[i].i < grupos_ordenados_por_tamanho_minimo[i].tam_maximo  and quantidade_elementos > 0 ){
                grupos_ordenados_por_tamanho_minimo[i].i +=1;
                quantidade_elementos-=1;
            }

        }

        int quantidade_pares = 0;

        for(int i = 0; i<grupos_ordenados_por_tamanho_minimo.size(); i++){
            quantidade_pares+= funcoes.quantidade_pares(grupos_ordenados_por_tamanho_minimo[i].i);
        }

        vector<Pair> distancias_ordenadas = instance.arr_Pair;
        funcoes.ordenar_distancias(distancias_ordenadas);

        double total = 0.0;

        int i2 = distancias_ordenadas.size()-1;
        for(int i =quantidade_pares-1;i >=0;i--){
            total+= (double) distancias_ordenadas[i2].get_distance_Element();
            i2-=1;
        }

        return total;



    }


    vector<vector<Grupo>> encontra_vizinhos(){


        Funcoes funcoes;
        //todos os vizinhos
        vector<vector<Grupo>> resultado;

        //para não mexer na solução
        vector<Grupo> solution = this->solucao;

        int quantidade_grupos = solution.size();

        //para não trocar elementos de um grupo mais de uma vez
        bool* lista_grupos_usados = new bool[quantidade_grupos];
        for(int i = 0;i<quantidade_grupos;i++){
            lista_grupos_usados[i] = false;
        }


        for(int i = 0; i<quantidade_grupos-1;i++){
            for(int i2=i;i<quantidade_grupos;i2++){

                if( (not lista_grupos_usados[i]) or (not lista_grupos_usados[i2]) ){
                    funcoes.trocaElementos(solution[i],solution[i2],0,0);
                    resultado.push_back(solucao);
                    funcoes.trocaElementos(solution[i],solution[i2],0,0);
                    lista_grupos_usados[i] = true;
                    lista_grupos_usados[i2] = true;
                }

            }

        }
        resultado.push_back(solucao);


        delete lista_grupos_usados;
        this->vizinhos = resultado;
        return resultado;
    }

};